import javax.swing.ImageIcon;
import javax.swing.JButton;

/**
 * 
 * @author Todd
 *
 */
public class Platoon extends Sensor{

	private boolean inSafeZone;
	
	public Platoon(String name, JButton tile, ImageIcon image) {
		super(name, tile, image);
		inSafeZone = false;
	}

	public void setInSafeZone(boolean inSafeZone) {
		this.inSafeZone = inSafeZone;
	}
	
	public boolean getInSafeZone() {
		return inSafeZone;
	}
}
