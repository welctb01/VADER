import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;

/**
 * 
 * @author Todd
 *
 */
public class R2D2 extends Sensor{

	private Icon previousImageIcon;
	
	public R2D2(String name, JButton tile, ImageIcon image) {
		super(name, tile, image);
		previousImageIcon = null;
	}
		
	public Icon getPreviousImageIcon() {
		return previousImageIcon;
	}
	
	public void setPreviousImageIcon(Icon previousImageIcon) {
		this.previousImageIcon = previousImageIcon;
	}
	
	public void showPreviousImageIcon() {
		getTile().setIcon(previousImageIcon);
	}
}
