import javax.swing.ImageIcon;
import javax.swing.JButton;

/**
 * 
 * @author Todd
 *
 */
public class Sensor {

	private JButton tile;
	private String name;
	private String id;
	private int row;
	private int col;
	private boolean isDetection;
	private int det_x;
	private int det_y;
	private ImageIcon image;

	
	public Sensor(String name, JButton tile, ImageIcon image) {
		this.name = name;
		this.tile = tile;
		this.image = image;
		
		id = tile.getName();
		
		row = Util.parseRow(id);
		col = Util.parseCol(id);
		
		isDetection = false;
		det_x = 0;
		det_y = 0;
	}
	
	public JButton getTile() {
		return tile;
	}
	
	public void setTile(JButton tile) {
		this.tile = tile;
		String text = tile.getName();
		setID(text);
		setRow(Util.parseRow(text));
		setCol(Util.parseCol(text));
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getID() {
		return id;
	}
	
	public void setID(String id) {
		this.id = id;
	}
	
	public int getRow() {
		return row;
	}
	
	public void setRow(int row) {
		this.row = row;
	}
	
	public int getCol() {
		return col;
	}
	
	public void setCol(int col) {
		this.col = col;
	}
	
	public boolean getIsDetection() {
		return isDetection;
	}
	
	public void setIsDetection(boolean isDetection) {
		this.isDetection = isDetection;
	}
	
	public int getDetX() {
		return det_x;
	}
	
	public void setDetX(int det_x) {
		this.det_x = det_x;
	}
	
	public int getDetY() {
		return det_y;
	}
	
	public void setDetY(int det_y) {
		this.det_y = det_y;
	}
	
	
	public void setImage(ImageIcon image) {
		this.image = image;
	}
	
	public ImageIcon getImage() {
		return image;
	}
	
	public void showImageIcon() {
		tile.setIcon(image);
	}
	
	public void hideImageIcon() {
		tile.setIcon(null);
	}
		
	public String toString() {
		return '[' + name + ',' + id + ']';
	}
}
