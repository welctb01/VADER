import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.swing.*;

/**
 * 
 * @author Todd
 *
 */
public class GUI extends JFrame {

	private static final long serialVersionUID = 1L;
	final int ROWS = 20;
	final int COLS = 20;
	final int PLATOON_COUNT = 3;
	final int R2D2_COUNT = 6;
	final int R2D2_MANHATTAN_RANGE = 5;
	final int PLATOON_MANHATTAN_RANGE = 4;
	final int PLATOON_DET_RATE = 75; // 75%
	final String PLATOON_1_LABEL = "Platoon KENOBI: ";
	final String PLATOON_2_LABEL = "Platoon CHEWIE: ";
	final String PLATOON_3_LABEL = "Platoon C3P0: ";
	
	final JCheckBox showDetectionCheckbox = new JCheckBox("Show Detections");
	final JCheckBox showR2D2Checkbox = new JCheckBox("Show R2D2s");
	final JButton resetButton = new JButton("Reset");
	
	final JLabel detectionLabel = new JLabel("");
	final JLabel tickLabel = new JLabel("0");
	final JLabel platoon1Label = new JLabel(PLATOON_1_LABEL);
	final JLabel platoon2Label = new JLabel(PLATOON_2_LABEL);
	final JLabel platoon3Label = new JLabel(PLATOON_3_LABEL);
	final JLabel platoon1InfoLabel = new JLabel("");
	final JLabel platoon2InfoLabel = new JLabel("");
	final JLabel platoon3InfoLabel = new JLabel("");

	JButton lastPlatoonLocation;
	JButton safeZone;
	JButton tiles[][] = new JButton[ROWS][COLS];
	Platoon platoons[] = new Platoon[PLATOON_COUNT];
	R2D2 r2d2s[] = new R2D2[R2D2_COUNT];

	int tickCount = 0;
	int detectionCount = 0;
	boolean isMove = false;
	
	ImageIcon worn;
	ImageIcon grass;
	ImageIcon rebel;
	ImageIcon obi;
	ImageIcon chewy;
	ImageIcon c3p0;
	ImageIcon r2;

	public GUI(String name) {
		super(name);
		this.setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("images/darth.png")));		
		
		// Listener for key presses
		KeyboardFocusManager manager = KeyboardFocusManager.getCurrentKeyboardFocusManager();
        manager.addKeyEventDispatcher(new MyDispatcher());
	}

	public void addComponentsToPane(final Container pane) {
		JPanel grid = new JPanel();
		grid.setLayout(new GridLayout(0, COLS));
		JPanel controls = new JPanel();
		controls.setLayout(new GridLayout(2, 6));
		
		// Load images
		try {
			worn = new ImageIcon(ImageIO.read(getClass().getResource("images/worn_grass.jpg")));
			grass = new ImageIcon(ImageIO.read(getClass().getResource("images/grass.jpg")));
			rebel = new ImageIcon(ImageIO.read(getClass().getResource("images/rebel.png")));
			obi = new ImageIcon(ImageIO.read(getClass().getResource("images/kenobi.png")));
			chewy = new ImageIcon(ImageIO.read(getClass().getResource("images/chewie.png")));
			c3p0 = new ImageIcon(ImageIO.read(getClass().getResource("images/c3p0.png")));
			r2 = new ImageIcon(ImageIO.read(getClass().getResource("images/r2d2.png")));
		} catch (Exception e) {
			e.printStackTrace();
		}
		

		// Process button presses on tiles
		ActionListener tileButtonListener = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				processEvent(e, null);
			}
		};

		// Process detection check box
		showDetectionCheckbox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JCheckBox cb = (JCheckBox) e.getSource();
				if (cb.isSelected()) {
					detectionLabel.setText(String.valueOf(detectionCount));
				} else {
					detectionLabel.setText("");
				}
			}
		});

		// Process R2D2 check box
		showR2D2Checkbox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JCheckBox cb = (JCheckBox) e.getSource();
				showR2D2(cb.isSelected());
			}
		});

		// Process the reset button press
		resetButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// Reset tiles
				for (int x = 0; x < ROWS; x++) {
					for (int y = 0; y < COLS; y++) {
						tiles[x][y].setIcon(grass);
					}
				}
				
				lastPlatoonLocation = null;

				// Add platoons and R2D2s to the grid
				setupLocations();

				// Reset values and controls
				tickCount = 0;
				detectionCount = 0;
				showDetectionCheckbox.setSelected(false);
				showR2D2Checkbox.setSelected(false);
				detectionLabel.setText("");
				tickLabel.setText("0");
				
				for(int i = 0; i < PLATOON_COUNT; i++) {
					clearPlatoonLabel(i);
				}
			}
		});

		// Add tiles
		for (int x = 0; x < ROWS; x++) {
			for (int y = 0; y < COLS; y++) {
				JButton tile = new JButton();
				tile.setName("(" + x + "," + y + ")");
				tile.setPreferredSize(new Dimension(70, 70));
				tile.setIcon(grass);
				tile.addActionListener(tileButtonListener);				
				grid.add(tile);
				tiles[x][y] = tile;
			}
		}

		// Add platoons and R2D2s to the grid
		setupLocations();		
		
		// Add controls
		controls.add(platoon1Label);
		controls.add(platoon2Label);
		controls.add(platoon3Label);
		controls.add(new JLabel("Tick:"));
		controls.add(showDetectionCheckbox);
		controls.add(showR2D2Checkbox);
		controls.add(platoon1InfoLabel);
		controls.add(platoon2InfoLabel);
		controls.add(platoon3InfoLabel);
		controls.add(tickLabel);
		controls.add(detectionLabel);
		controls.add(resetButton);

		// Allow the grid to be scrolled
		JScrollPane panelPane = new JScrollPane(grid);

		// Add components to frame
		pane.add(controls, BorderLayout.NORTH);
		pane.add(panelPane, BorderLayout.CENTER);
	}
	
	/**
	 * Add platoons, R2D2s, and safezone to the grid
	 */
	private void setupLocations() {		
		// Add platoons at static tiles
		platoons[0] = new Platoon("P1", tiles[0][0], obi);
		platoons[0].showImageIcon();
		platoons[1] = new Platoon("P2", tiles[9][3], chewy);
		platoons[1].showImageIcon();
		platoons[2] = new Platoon("P3", tiles[3][9], c3p0);
		platoons[2].showImageIcon();

		// Add safezone at last tile
		safeZone = tiles[ROWS - 1][COLS - 1];
		safeZone.setBackground(Color.YELLOW);
		safeZone.setIcon(rebel);
		
		// Add R2D2s at random tiles
		Random rand = new Random(System.currentTimeMillis());
		JButton jb = new JButton();
		
		for (int i = 0; i < R2D2_COUNT; i++) {
			String name = "R" + (i + 1);
			String id;
			int row, col;

			// Generate random tile for R2D2
			do {
				row = rand.nextInt(ROWS);
				col = rand.nextInt(COLS);
				id = "(" + row + ',' + col + ')';
				jb.setName(id);
			} while (isTileTaken(jb));

			r2d2s[i] = new R2D2(name, tiles[row][col], r2);
		}
	}

	/**
	 * Check if the tile is available
	 * 
	 * @param row
	 * @param col
	 * @return
	 */
	private boolean isTileTaken(JButton tile) {
		return (isPlatoon(tile) || isR2D2(tile) || isSafeZoneRange(tile));
	}

	/**
	 * Check if tile is a platoon
	 * 
	 * @param tile
	 * @return
	 */
	private boolean isPlatoon(JButton tile) {
		for (int i = 0; i < PLATOON_COUNT; i++) {
			if (tile.getName().equalsIgnoreCase(platoons[i].getID())
					&& !platoons[i].getInSafeZone()) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Get the array index of the platoon at the specified tile
	 * 
	 * @param tile
	 * @return
	 */
	private int findPlatoon(JButton tile) {
		int index = 0;
		for (int i = 0; i < PLATOON_COUNT; i++) {
			if (tile.getName().equalsIgnoreCase(platoons[i].getID())
					&& !platoons[i].getInSafeZone()) {
				return i;
			}
		}
		return index;
	}

	/**
	 * Update platoon location
	 * 
	 * @param oldTile
	 * @param newTile
	 */
	private void updatePlatoonLocation(JButton oldTile, JButton newTile) {
		int index = findPlatoon(oldTile);
		platoons[index].setTile(newTile);
	}

	/**
	 * Check if an R2D2 is already at that tile
	 * 
	 * @param tile
	 * @return
	 */
	private boolean isR2D2(JButton tile) {
		for (int i = 0; i < R2D2_COUNT; i++) {
			if (r2d2s[i] == null) {
				break;
			} else if (r2d2s[i].getID().equalsIgnoreCase(tile.getName())) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Check if tile is the safezone
	 * 
	 * @param tile
	 * @return
	 */
	private boolean isSafeZone(JButton tile) {
		return safeZone.getName().equalsIgnoreCase(tile.getName());
	}

	/**
	 * Check if the tile is in range of safezone (<=5 Manhattan distance)
	 * 
	 * @param tile
	 * @return
	 */
	private boolean isSafeZoneRange(JButton tile) {
		return Util.calculateManhattan(safeZone, tile) <= R2D2_MANHATTAN_RANGE;
	}

	/**
	 * Check if the move is valid
	 * 
	 * @param tile
	 * @return
	 */
	private boolean isValidMove(JButton newTile, JButton oldTile) {
		if (isPlatoon(newTile)) {
			return false;
		}

		try {
			String newID = newTile.getName();
			int newRow = Util.parseRow(newID);
			int newCol = Util.parseCol(newID);

			String oldID = oldTile.getName();
			int oldRow = Util.parseRow(oldID);
			int oldCol = Util.parseCol(oldID);

			if (newRow == oldRow) {
				if (newCol == oldCol - 1 || newCol == oldCol + 1) {
					return true;
				}
			} else if (newCol == oldCol) {
				if (newRow == oldRow - 1 || newRow == oldRow + 1) {
					return true;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return false;
	}

	/**
	 * Determine how many R2D2s detected the platoon movement
	 * 
	 * @param tile
	 * @return
	 */
	private ArrayList<Integer> platoonDetected(JButton tile) {
		ArrayList<Integer> r2d2_det = new ArrayList<Integer>();

		for (int i = 0; i < R2D2_COUNT; i++) {
			int m = Util.calculateManhattan(tile, r2d2s[i].getTile());
			if (m <= R2D2_MANHATTAN_RANGE) {
				r2d2_det.add(i);
			}
		}
		
		return r2d2_det;
	}

	/**
	 * Show/hide R2D2 locations
	 * 
	 * @param show
	 */
	private void showR2D2(boolean show) {
		if (show) {
			for (int i = 0; i < R2D2_COUNT; i++) {
				R2D2 r2d2 = r2d2s[i];
				r2d2.setPreviousImageIcon(r2d2.getTile().getIcon());
				r2d2.getTile().setBackground(Color.RED);
				r2d2.showImageIcon();
			}
		} else {
			for (int i = 0; i < R2D2_COUNT; i++) {
				R2D2 r2d2 = r2d2s[i];
				r2d2.showPreviousImageIcon();
			}
		}
	}
	
	/**
	 * Update platoon label
	 * 
	 * @param index
	 * @param count
	 * @param detects
	 */
	private void updatePlatoonLabel(int index, int count, String detects) {
		switch (index) {
		case 0:
			platoon1Label.setText(PLATOON_1_LABEL + count + " R2D2 Dectected");
			platoon1InfoLabel.setText(detects.substring(0, detects.length() - 2));
			break;
		case 1:
			platoon2Label.setText(PLATOON_2_LABEL + count + " R2D2 Dectected");
			platoon2InfoLabel.setText(detects.substring(0, detects.length() - 2));
			break;
		case 2:
			platoon3Label.setText(PLATOON_3_LABEL + count + " R2D2 Dectected");
			platoon3InfoLabel.setText(detects.substring(0, detects.length() - 2));
			break;
		}
	}
	
	/**
	 * Clear platoon label
	 * 
	 * @param index
	 */
	private void clearPlatoonLabel(int index) {
		switch (index) {
		case 0:
			platoon1Label.setText(PLATOON_1_LABEL);
			platoon1InfoLabel.setText("");
			break;
		case 1:
			platoon2Label.setText(PLATOON_2_LABEL);
			platoon2InfoLabel.setText("");
			break;
		case 2:
			platoon3Label.setText(PLATOON_3_LABEL);
			platoon3InfoLabel.setText("");
			break;
		}
	}
	
	/**
	 * Process events from button clicks and key presses
	 * 
	 * @param ae
	 * @param ke
	 */
	private void processEvent(ActionEvent ae, KeyEvent ke) {
		JButton tile = null;
		
		// Check for button click or key press event
		if (ae != null) {
			tile = (JButton) ae.getSource();
		} else if (lastPlatoonLocation != null){
			int key = ke.getKeyCode();
			int row = Util.parseRow(lastPlatoonLocation.getName());
			int col = Util.parseCol(lastPlatoonLocation.getName());

			// Determine arrow key pressed
		    if (key == KeyEvent.VK_LEFT) {
		    	if(col > 0) {
		    		tile = tiles[row][col - 1];
		    	}
		    } else if (key == KeyEvent.VK_RIGHT) {
		    	if (col < COLS - 1) {
		    		tile = tiles[row][col + 1];
		    	}
		    } else if (key == KeyEvent.VK_UP) {
		        if (row > 0) {
		    		tile = tiles[row - 1][col];
		        }
		    } else if (key == KeyEvent.VK_DOWN) {
		    	if (row < ROWS - 1) {
		    		tile = tiles[row + 1][col];
		    	}
		    }
		}
		
		if(tile == null) {
			return;
		}

		// Hide R2D2s if showing
		if (showR2D2Checkbox.isSelected()) {
			showR2D2Checkbox.setSelected(false);
			showR2D2(false);
		}

		// Check if a valid move was made
		if (lastPlatoonLocation != null	&& isValidMove(tile, lastPlatoonLocation)) {
			// Update locations
			updatePlatoonLocation(lastPlatoonLocation, tile);
			lastPlatoonLocation.setIcon(worn);
			lastPlatoonLocation = tile;
			
			int platoonLocation = findPlatoon(tile);

			// Check if the platoon made it to the safezone
			if (isSafeZone(tile)) {
				platoons[platoonLocation].setInSafeZone(true);
				lastPlatoonLocation = null;
			} else {
				platoons[platoonLocation].showImageIcon();
			}

			// Update tick count
			tickCount++;
			tickLabel.setText(String.valueOf(tickCount));

			// Update count of platoon being detected by R2D2s
			ArrayList<Integer> r2d2_det = platoonDetected(tile);
			detectionCount += r2d2_det.size();
			
			int index = findPlatoon(tile);
			int count = 0;

			// Check if platoon detected any R2D2s
			if (r2d2_det.size() > 0) {
				Random rand = new Random(System.currentTimeMillis());
				String detects = "";

				for (Integer i : r2d2_det) {
					int m = Util.calculateManhattan(tile, r2d2s[i].getTile());
					
					if (m <= PLATOON_MANHATTAN_RANGE) {
						// PLATOON_DET_RATE percent chance of platoon detecting/reporting R2D2
						if (rand.nextInt(100) < PLATOON_DET_RATE) {
							int xOffset = Util.calculateOffsetX(tile, r2d2s[i].getTile());
							int yOffset = Util.calculateOffsetY(tile, r2d2s[i].getTile());
							count++;
							detects += "(" + xOffset + "," + yOffset + "), "; 
						}
					}
				}
				
				// Update platoon detection info
				if(count > 0) {
					updatePlatoonLabel(index, count, detects);					
				} else {
					clearPlatoonLabel(index);
				}
			} else {
				clearPlatoonLabel(index);
			}					
		} else if (isPlatoon(tile)) {
			lastPlatoonLocation = tile;
		} else {
			lastPlatoonLocation = null;
		}

		// Show detection count
		if (showDetectionCheckbox.isSelected()) {
			detectionLabel.setText(String.valueOf(detectionCount));
		}
	}
	
	/**
	 * Listener for key presses
	 * 
	 * @author Todd
	 *
	 */
	 private class MyDispatcher implements KeyEventDispatcher {
		public boolean dispatchKeyEvent(KeyEvent e) {
			if (e.getID() == KeyEvent.KEY_PRESSED) {
				processEvent(null, e);
			}
			return false;
		}
	}
}
