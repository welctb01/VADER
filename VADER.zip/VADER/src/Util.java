import javax.swing.JButton;

/**
 * 
 * @author Todd
 *
 */
public class Util {

	public static int calculateManhattan(JButton tile1, JButton tile2) {		
		return calculateOffsetY(tile1, tile2) + calculateOffsetX(tile1, tile2);
	}
	
	public static int calculateOffsetX(JButton tile1, JButton tile2) {
		return Math.abs(parseCol(tile1.getName()) - parseCol(tile2.getName()));
	}
	
	public static int calculateOffsetY(JButton tile1, JButton tile2) {
		return Math.abs(parseRow(tile1.getName()) - parseRow(tile2.getName()));
	}
	
	public static int parseRow(String id) {
		int row = 0;		
		try {
			row = Integer.parseInt(id.substring(id.indexOf('(') + 1, id.indexOf(',')));
		} catch(Exception e) {
			e.printStackTrace();
		}
		return row;
	}
	
	public static int parseCol(String id) {
		int col = 0;		
		try {
			col = Integer.parseInt(id.substring(id.indexOf(',') + 1, id.indexOf(')')));
		} catch(Exception e) {
			e.printStackTrace();
		}
		return col;
	}
}
